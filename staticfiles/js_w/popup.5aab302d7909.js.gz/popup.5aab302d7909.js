// const item = document.getElementById('item-popup');
// const popup = document.getElementById('popup');
// const tableColumns = document.querySelectorAll('#table-column-pd')
// const btnOptions = document.querySelectorAll('#dropdownMenuButton1')


// tableColumns.forEach((column)=>{
//     column.addEventListener('click',(e)=>{
//         const rect = column.getBoundingClientRect();
//         console.log(e)
//         // popup.style.left = `${e.clietX}px`;
//         // popup.style.top = `${e.clientY}px`;
//         // popup.style.display = 'block';
//     })
// })

// item.addEventListener('click', (event) => {
//     const rect = item.getBoundingClientRect();
//     popup.style.left = `${rect.left}px`;
//     popup.style.top = `${rect.bottom}px`;
//     popup.style.display = 'block';
// });

// document.addEventListener('click', (event) => {
//     if (!popup.contains(event.target) && event.target !== item) {
//         popup.style.display = 'none';
//     }
// });
