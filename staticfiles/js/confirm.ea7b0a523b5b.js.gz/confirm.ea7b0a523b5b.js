

function verificar() {

    let resultado = window.confirm('Estas seguro de borrar el proyecto?');
    if (resultado === true) {
        return true
    } else {
        return false
    }

}


function confirm_delete_folder() {

    let resultado = window.confirm('Estás seguro de borrar la carpeta?, esta accción eliminará todo los archivos que contenga');
    if (resultado === true) {
        return true
    } else {
        return false
    }

}

function confirm_delete_file() {

    let resultado = window.confirm('¿Estás seguro de borrar el proyecto?');
    if (resultado === true) {
        return true
    } else {
        return false
    }

}


function confirm_delete_order() {

    let resultado = window.confirm('¿Realmente quieres borrar la orden de compra?');
    if (resultado === true) {
        return true
    } else {
        return false
    }

}

function confirm_delete_remission() {

    let resultado = window.confirm('¿Realmente quieres borrar la remisión?');
    if (resultado === true) {
        return true
    } else {
        return false
    }

}

function confirm_delete_entry() {

    let resultado = window.confirm('¿Estas seguro de borrar la entrada?');
    if (resultado === true) {
        return true
    } else {
        return false
    }

}

function confirm_delete_order_product() {

    let resultado = window.confirm('¿Estas seguro de borrar el producto de la orden de compra?');
    if (resultado === true) {
        return true
    } else {
        return false
    }

}
function confirm_delete_remission_product() {

    let resultado = window.confirm('¿Estas seguro de borrar el producto de la remisión?');
    if (resultado === true) {
        return true
    } else {
        return false
    }

}


function confirm_delete_product() {

    let resultado = window.confirm('¿Estas seguro de borrar el producto?');
    if (resultado === true) {
        return true
    } else {
        return false
    }

}

function confirm_delete_invoice() {

    let resultado = window.confirm('¿Realmente quieres borrar la factura?');
    if (resultado === true) {
        return true
    } else {
        return false
    }

}